import { Component } from '@angular/core';

@Component({
  selector: 'app-card-hover',
  templateUrl: './card-hover.component.html',
  styleUrls: ['./card-hover.component.scss']
})
export class CardHoverComponent {

}
